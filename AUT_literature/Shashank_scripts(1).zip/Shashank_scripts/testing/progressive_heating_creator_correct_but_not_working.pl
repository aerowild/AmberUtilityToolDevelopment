#!/usr/bin/perl
#This script is written to create various windows of input files of different temperature, duration and timesteps simulations. By default, this script will create 10 windows as per follwoing scheme:
#1)	300K -> 320K	timestep:2fs	duration: 400ps
#2)	320K -> 340K	timestep:2fs	duration: 400ps
#3)	340K -> 360K	timestep:2fs	duration: 400ps
#4)	360K -> 380K	timestep:2fs	duration: 400ps
#5)	380K -> 400K	timestep:2fs	duration: 400ps
#6)	400K -> 420K	timestep:1.5fs	duration: 300ps
#7)	420K -> 440K	timestep:1.5fs	duration: 240ps
#8)	440K -> 460K	timestep:1fs	duration: 180ps
#9)	460K -> 480K	timestep:1fs	duration: 100ps
#10)	480K -> 500K	timestep:1fs	duration: 100ps

$MD_fixed_params1 = 'PROTWIN: Progressive Heating
&cntrl
imin = 0,
irest = 1,
ntx = 5,
ig = -1,
ntc = 2,
ntf = 2,
cut = 10.0,
ntb = 2,
ntp = 1,
pres0 = 1.0,
taup = 2.0,
ntr = 0,
iwrap = 1,';
$MD_fixed_params2 ='
ntwe = 2000,
ntpr = 2000,
ntwx = 2000,
ntwr = 10000
/';

$dt = 0.002;
$tempi = 300;
$temp0 = 320;
$nstlim = 200000;

$window = 1;
while($window <= 10)
{
mkdir "Heating_win$window";
chdir "Heating_win$window";

#To write an input file
$write_infile = "Heating_win$window".'.in';
open(WRITEIN, ">:encoding(UTF-8)", "$write_infile");

#Writing .in files
if($window <= 5 )
{
print WRITEIN "$MD_fixed_params1","\ntempi = $tempi,","\ntemp0 = $temp0,","\n",'ntt = 3,',"\n",'gamma_ln = 10.0,',"\nnstlim=$nstlim,","\ndt = $dt,","$MD_fixed_params2";
}elsif($window == 6 ){
print WRITEIN "$MD_fixed_params1","\ntempi = $tempi,","\ntemp0 = $temp0,","\n",'ntt = 3,',"\n",'gamma_ln = 10.0,',"\ndt = 0.0015,","\nnstlim=200000,","\ndt = $dt,","$MD_fixed_params2";
}elsif($window == 7 ){
print WRITEIN "$MD_fixed_params1","\ntempi = $tempi,","\ntemp0 = $temp0,","\n",'ntt = 3,',"\n",'gamma_ln = 10.0,',"\ndt = 0.0015,","\nnstlim=160000,","\ndt = $dt,","$MD_fixed_params2";
}elsif($window == 8 ){
print WRITEIN "$MD_fixed_params1","\ntempi = $tempi,","\ntemp0 = $temp0,","\n",'ntt = 3,',"\n",'gamma_ln = 10.0,',"\ndt = 0.0015,","\nnstlim=120000,","\ndt = $dt,","$MD_fixed_params2";
}elsif($window >= 9 ){
print WRITEIN "$MD_fixed_params1","\ntempi = $tempi,","\ntemp0 = $temp0,","\n",'ntt = 3,',"\n",'gamma_ln = 10.0,',"\ndt = 0.001,","\nnstlim=100000,","\ndt = $dt,","$MD_fixed_params2";
}else {print "Something extraordinary happened\n"}

chdir '..';
$window = $window + 1;
$tempi = $tempi + 20;
$temp0 = $temp0 + 20;
}


