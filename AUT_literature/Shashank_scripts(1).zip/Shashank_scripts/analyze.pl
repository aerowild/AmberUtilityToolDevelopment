#!/usr/bin/perl -w
use warnings;
use diagnostics;
unlink 'analyze.log';
unlink 'analyze_error.log';
open (STDOUT,  "| tee -ai analyze.log");
open (STDERR,  "| tee -ai analyze_error.log");

mkdir 'analysis';
chdir 'analysis';
mkdir 'quality';
chdir 'quality';
system ('process_mdout.perl ../../heating/heat1.out ../../heating/heat2.out ../../heating/heat3.out ../../heating/heat4.out ../../heating/heat5.out ../../heating/heat6.out ../../equilibration/eql1.out ../../equilibration/eql2.out ../../equilibration/eql3.out ../../equilibration/eql4.out ../../productionMD/productionMD.out');
chdir '..';

system('cp ../topology/complexsolv.prmtop complexsolv.prmtop');
system('cp ../topology/complexsolv.pdb complexsolv.pdb');

open(WRITERMSDINALL, ">measure_rmsd_all.trajin");
print WRITERMSDINALL 'trajin ../heating/heat1.mdcrd
trajin ../heating/heat2.mdcrd
trajin ../heating/heat3.mdcrd
trajin ../heating/heat4.mdcrd
trajin ../heating/heat5.mdcrd
trajin ../heating/heat6.mdcrd
trajin ../equilibration/eql1.mdcrd
trajin ../equilibration/eql2.mdcrd
trajin ../equilibration/eql3.mdcrd
trajin ../equilibration/eql4.mdcrd
trajin ../productionMD/productionMD_out.mdcrd
reference complexsolv.pdb
rms reference out proteinBB_rmsd_all.dat @N,CA,C time 1.0
rms reference out UNK_rmsd_all.dat :UNK time 1.0
rms reference out complex_rmsd_all_wrt_first.dat :UNK:|::C* time 1.0';


open(WRITERMSDIN, ">measure_rmsd_eqlNpro.trajin");
print WRITERMSDIN 'trajin ../equilibration/eql1.mdcrd
trajin ../equilibration/eql2.mdcrd
trajin ../equilibration/eql3.mdcrd
trajin ../equilibration/eql4.mdcrd
trajin ../productionMD/productionMD_out.mdcrd
reference complexsolv.pdb
rms reference out proteinBB_rmsd_eqlpro.dat @N,CA,C time 1.0
rms first out proteinBB_rmsd_eqlpro_wrt_first.dat @N,CA,C time 1.0
rms reference out UNK_rmsd_eqlpro.dat :UNK time 1.0
rms first out UNK_rmsd_eqlpro_wrt_first.dat :UNK time 1.0
rms first out complex_rmsd_eqlpro_wrt_first.dat :UNK:|::C* time 1.0
rms reference out complex_rmsd_eqlpro.dat :UNK:|::C*  time 1.0';

open(WRITERMSDINPRO, ">measure_rmsd_production.trajin");
print WRITERMSDINPRO 'trajin ../productionMD/productionMD_out.mdcrd
reference complexsolv.pdb
rms reference out proteinBB_rmsd_production.dat @N,CA,C time 1.0
rms first out proteinBB_rmsd_production_wrt_first.dat @N,CA,C time 1.0
rms reference out UNK_rmsd_production_wrt.dat :UNK time 1.0
rms first out UNK_rmsd_production_wrt_first.dat :UNK time 1.0
rms first out complex_rmsd_production_wrt_first.dat :UNK:|::C* time 1.0
rms reference out complex_rmsd_production.dat :UNK:|::C*  time 1.0';


system('ptraj complexsolv.prmtop < measure_rmsd_all.trajin > measure_rmsd_all.out');
system('ptraj complexsolv.prmtop < measure_rmsd_eqlNpro.trajin > measure_rmsd_eqlpro.out');
system('ptraj complexsolv.prmtop < measure_rmsd_production.trajin > measure_rmsd_production.out');

mkdir 'rmsd_data';
system('mv *.dat rmsd_data/');
