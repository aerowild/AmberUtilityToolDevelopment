export AMBERHOME=C:\Users\Shashank\Google Drive\Java_programming\My_prog\AmberUtilityToolDevelopment\src
export PATH=$PATH:AMBERHOME/bin:$AMBERHOME/AmberTools/bin
cd C:\Users\Shashank\Google Drive\Java_programming\My_prog\AmberUtilityToolDevelopment\outputFiles
tleap -f C:\Users\Shashank\Google Drive\Java_programming\My_prog\AmberUtilityToolDevelopment\outputFiles/generateTopology.source
